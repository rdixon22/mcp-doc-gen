---
title: "list_wiki_pages"
description: "Browse WikiVault pages by type or tag via filesystem scan — returns title, type, tags, and file path without loading page bodies."
audience: both
topics: [wiki, browse, filesystem, enumeration, filtering]
mcp_tools: [list_wiki_pages]
doc_phase: 1
reviewed: pending
generated_at: 2026-05-23T08:04:54+00:00
model: claude-sonnet-4-6
---

# `list_wiki_pages`

Browse WikiVault pages with optional filters. Returns a lightweight listing — title, type, tags, and relative file path — without loading page bodies. Operates via filesystem scan, so no database connection is required.

Use `list_wiki_pages` when you want to **enumerate** pages by type or tag. When you want to find pages by meaning or keyword, use [`search_wiki`](search-wiki.md) instead.

## Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `type` | string (enum) | No | — | Restrict results to one page type. See valid values below. |
| `tag` | string | No | — | Filter by a single tag (lowercase-kebab format). |
| `limit` | number | No | `50` | Maximum number of results to return. |

### `type` enum values

| Value | Description |
|-------|-------------|
| `wiki_person` | Person profiles |
| `wiki_project` | Project pages |
| `wiki_concept` | Concept definitions |
| `wiki_area` | Area/domain pages |
| `wiki_topic` | Topic overview pages |
| `raw_article` | Imported articles |
| `raw_book` | Imported book notes |
| `raw_daily` | Daily notes |
| `raw_attachment` | Imported attachments |

## Returns

An array of page objects. Each object contains:

| Field | Type | Description |
|-------|------|-------------|
| `title` | string | Human-readable page title |
| `type` | string | Page type (one of the enum values above) |
| `tags` | string[] | List of lowercase-kebab tags on the page |
| `file_path` | string | Relative path to the file in WikiVault |

Page bodies are **not** included. To read full content, pass the returned `file_path` or `title` to [`read_wiki_page`](read-wiki-page.md).

## Usage Examples

### Enumerate all person pages

```json
{
  "name": "list_wiki_pages",
  "arguments": {
    "type": "wiki_person"
  }
}
```

Returns all `wiki_person` pages (up to 50). Then call `read_wiki_page` on the relevant entry:

```json
{
  "name": "read_wiki_page",
  "arguments": {
    "identifier": "wiki/people/Alice-Smith.md"
  }
}
```

### Find all stub pages

```json
{
  "name": "list_wiki_pages",
  "arguments": {
    "tag": "stub"
  }
}
```

Returns every page carrying the `stub` tag, across all types.

### List all project pages tagged with a topic

```json
{
  "name": "list_wiki_pages",
  "arguments": {
    "type": "wiki_project",
    "tag": "machine-learning",
    "limit": 20
  }
}
```

Returns up to 20 project pages tagged `machine-learning`.

### List all raw articles (no filters)

```json
{
  "name": "list_wiki_pages",
  "arguments": {
    "type": "raw_article",
    "limit": 100
  }
}
```

## Common Use Cases

| Goal | Approach |
|------|----------|
| Find a specific person when you don't know the exact title | `list_wiki_pages` with `type: "wiki_person"`, scan titles, then `read_wiki_page` |
| Identify stubs that need fleshing out | `list_wiki_pages` with `tag: "stub"` |
| Audit all pages in a topic area | `list_wiki_pages` with the relevant tag |
| Check whether a project page exists before creating one | `list_wiki_pages` with `type: "wiki_project"`, scan results |
| Browse recently imported articles | `list_wiki_pages` with `type: "raw_article"` |

## Choosing Between `list_wiki_pages` and `search_wiki`

| Situation | Tool |
|-----------|------|
| You know the type or tag you want | `list_wiki_pages` |
| You have a concept or keyword to match | [`search_wiki`](search-wiki.md) |
| You want chronological/structural browsing | `list_wiki_pages` |
| You need semantic relevance ranking | [`search_wiki`](search-wiki.md) |
| Database is unavailable | `list_wiki_pages` (filesystem only) |

## Notes

- **No database required.** The tool reads directly from the WikiVault filesystem, making it reliable even when Supabase is unavailable.
- **No bodies returned.** Results are intentionally lightweight. Always follow up with [`read_wiki_page`](read-wiki-page.md) to retrieve full content.
- **Tag format.** Tags are stored and matched as lowercase-kebab strings (e.g., `machine-learning`, `stub`, `action-required`).
- **Combining filters.** `type` and `tag` filters are additive — results must match both when both are supplied.