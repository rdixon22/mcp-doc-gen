---
title: "migrate_vault_file"
description: "Import a single Markdown file from MainVault into WikiVault, adding standardised frontmatter, stripping Dataview blocks, and indexing the content in Supabase."
audience: both
topics: [migration, import, vault, wiki, raw]
mcp_tools: [migrate_vault_file]
doc_phase: 1
reviewed: pending
generated_at: 2026-05-23T08:06:32+00:00
model: claude-sonnet-4-6
---

# migrate_vault_file

Copies a Markdown file from MainVault into WikiVault's `raw/` subfolder. During the copy the tool adds standardised frontmatter, strips Dataview blocks, embeds the content, and indexes it in Supabase. The original MainVault file is never modified.

This is a one-time import tool — use it during an initial vault migration or to bring in individual articles, books, daily notes, or attachments on demand.

## Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `source_path` | string | Yes | — | Absolute filesystem path to the MainVault source file, e.g. `"/Users/me/MainVault/Books/Thinking Fast and Slow.md"` |
| `target_type` | string (enum) | Yes | — | Destination subfolder category. One of: `raw_article`, `raw_book`, `raw_daily`, `raw_attachment` |
| `force` | boolean | No | `false` | If `true`, overwrites the file if it already exists in WikiVault. If `false` (default), the tool refuses to overwrite an existing file. |

### `target_type` values

| Value | Use for |
|-------|---------|
| `raw_article` | Articles, blog posts, clippings |
| `raw_book` | Book notes and highlights |
| `raw_daily` | Daily notes |
| `raw_attachment` | Attachments and miscellaneous files |

## Returns

The tool returns a confirmation of the migration. The exact response schema is not specified in the tool definition; expect at minimum a success or error status and the destination location within WikiVault.

If the file already exists in WikiVault and `force` is `false`, the tool returns an error rather than overwriting.

## What the tool does

The tool definition specifies these operations:

1. Copies the file from `source_path` into the WikiVault `raw/` subfolder determined by `target_type`.
2. Adds standardised frontmatter to the copied file.
3. Strips any Dataview blocks from the content.
4. Embeds the resulting content.
5. Indexes the entry in Supabase.

The original file at `source_path` is not touched.

> **Note:** Specific frontmatter fields generated, exact subfolder paths within `raw/`, and internal step ordering are implementation details not exposed by the tool definition.

## Usage examples

### Migrate a book-notes file

```json
{
  "name": "migrate_vault_file",
  "arguments": {
    "source_path": "/Users/me/MainVault/Books/Thinking Fast and Slow.md",
    "target_type": "raw_book"
  }
}
```

### Re-import a file, overwriting the existing WikiVault copy

```json
{
  "name": "migrate_vault_file",
  "arguments": {
    "source_path": "/Users/me/MainVault/Articles/Decision Making Under Uncertainty.md",
    "target_type": "raw_article",
    "force": true
  }
}
```

### Migrate a daily note

```json
{
  "name": "migrate_vault_file",
  "arguments": {
    "source_path": "/Users/me/MainVault/Daily/2024-03-15.md",
    "target_type": "raw_daily"
  }
}
```

## Behaviour notes

- **Safe by default:** Without `force: true`, the tool will not silently overwrite an existing WikiVault file. This prevents accidental data loss during incremental migrations.
- **Non-destructive:** The MainVault source file is never modified, regardless of the `force` setting.
- **Dataview cleanup:** Dataview query blocks are removed during import since they are not meaningful outside the MainVault context.
- **Automatic embedding and indexing:** After the file is written, it is embedded and indexed in Supabase, making it immediately searchable via [`search_wiki`](search-wiki.md) and [`search_all`](search-all.md).

## Related tools

| Tool | When to use |
|------|-------------|
| [`write_wiki_page`](write-wiki-page.md) | Create or update structured wiki pages (people, projects, concepts) — not raw imports |
| [`search_wiki`](search-wiki.md) | Search for the imported file after migration |
| [`list_wiki_pages`](list-wiki-pages.md) | Browse all raw files to confirm what has been migrated |
| [`append_wiki_log`](append-wiki-log.md) | Log the migration action for audit purposes |