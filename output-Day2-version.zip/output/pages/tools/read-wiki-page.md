---
title: "read_wiki_page"
description: "Read the full content and frontmatter of a WikiVault page by title or relative file path."
audience: both
topics: [wiki, read, frontmatter, knowledge-base]
mcp_tools: [read_wiki_page, write_wiki_page]
doc_phase: 1
reviewed: pending
generated_at: 2026-05-23T08:04:15+00:00
model: claude-sonnet-4-6
---

# read_wiki_page

Read the full content and frontmatter of a WikiVault page identified by either a human-readable title or a relative file path. **Always call this before [`write_wiki_page`](write-wiki-page.md) if the page may already exist** — never overwrite content you have not read.

## Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `identifier` | string | Yes | — | Page title (e.g. `"Alice Smith"`) or relative file path (e.g. `"wiki/people/Alice-Smith.md"`) |

## Returns

The tool returns the page's full Markdown body and its parsed frontmatter fields, along with the resolved file path. The exact shape of the response object is determined by the server runtime.

When the page does not exist, the tool returns a signal indicating the page was not found. This allows a caller to safely proceed with a new `write_wiki_page` call.

## Read-before-write protocol

Wiki writes must be preceded by a read whenever the page may already exist. This prevents clobbering data that was written in a previous session or by another tool call.

1. Call `read_wiki_page` with the target page title or path.
2. If the page exists, inspect the returned body and frontmatter.
3. Merge new information with the existing content.
4. Call `write_wiki_page` with the merged body.
5. Call `append_wiki_log` to record the action.

If `read_wiki_page` returns a not-found signal, you may call `write_wiki_page` directly to create the page.

## Usage examples

### Look up a person page by title

```json
{
  "name": "read_wiki_page",
  "arguments": {
    "identifier": "Alice Smith"
  }
}
```

### Look up a page by relative file path

```json
{
  "name": "read_wiki_page",
  "arguments": {
    "identifier": "wiki/people/Alice-Smith.md"
  }
}
```

### Full update workflow

```
// Step 1 — read current state
read_wiki_page({ identifier: "Alice Smith" })

// Step 2 — merge new facts into the returned body
// (done by the agent before the next call)

// Step 3 — write the merged result back
write_wiki_page({
  title: "Alice Smith",
  type: "wiki_person",
  body: "<merged markdown>",
  tags: ["engineering", "team-lead"]
})

// Step 4 — log the action
append_wiki_log({
  file_path: "wiki/people/Alice-Smith.md",
  summary: "Updated role and project assignments for Alice Smith"
})
```

## Notes

- Both identifier forms (title string and relative path) resolve to the same page. Use whichever you have available.
- Frontmatter is built automatically by `write_wiki_page` and is not supplied manually in the body. The returned frontmatter from `read_wiki_page` reflects whatever the server has stored.
- This tool is read-only — it never modifies the vault.