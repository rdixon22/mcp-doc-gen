---
title: "Tools Index"
description: "Complete technical reference for all Cortex MCP tools, organized by functional group with search selection guidance and write protocols."
audience: both
topics: [tools, reference, search, wiki, thoughts]
mcp_tools: [capture_thought, search_thoughts, list_thoughts, thought_stats, write_wiki_page, read_wiki_page, search_wiki, list_wiki_pages, append_wiki_log, search_all, search_messages, migrate_vault_file]
doc_phase: 1
reviewed: pending
generated_at: 2026-05-23T07:59:41+00:00
model: claude-sonnet-4-6
---

# Tools Index

## Thought Tools

| Tool | Description |
|------|-------------|
| [capture_thought](capture-thought.md) | Save a new note, insight, decision, or task — automatically extracts metadata on write. |
| [search_thoughts](search-thoughts.md) | Semantic search across captured thoughts only (excludes wiki pages). |
| [list_thoughts](list-thoughts.md) | Browse recently captured thoughts chronologically with optional type, topic, person, or date filters. |
| [thought_stats](thought-stats.md) | Return aggregate counts, type breakdown, top topics, and top people across all captured thoughts. |

## Wiki Tools

| Tool | Description |
|------|-------------|
| [write_wiki_page](write-wiki-page.md) | Create or overwrite a WikiVault markdown page; automatically embeds content and indexes it. |
| [read_wiki_page](read-wiki-page.md) | Read the full body and frontmatter of a WikiVault page by title or file path. |
| [search_wiki](search-wiki.md) | Semantic search across WikiVault pages only, with optional page-type filter. |
| [list_wiki_pages](list-wiki-pages.md) | Browse WikiVault pages by type or tag without a query; returns titles, types, tags, and paths. |
| [append_wiki_log](append-wiki-log.md) | Append a one-line audit entry to `log.md` after any wiki write or significant decision. |

## Cross-Store & Utility Tools

| Tool | Description |
|------|-------------|
| [search_all](search-all.md) | Semantic search across both captured thoughts and WikiVault pages simultaneously; results tagged `[thought]` or `[wiki]`. |
| [search_messages](search-messages.md) | Semantic search across past AI chat conversation history. |
| [migrate_vault_file](migrate-vault-file.md) | One-time import: copy a MainVault file into WikiVault `raw/`, normalize frontmatter, and index it. |

---

## Choosing the Right Search Tool

| Target scope | Recommended tool |
|---|---|
| Captured thoughts only (notes, tasks, observations) | [search_thoughts](search-thoughts.md) |
| Wiki pages only (people, projects, concepts, areas) | [search_wiki](search-wiki.md) |
| Everything at once — broadest possible context | [search_all](search-all.md) |
| Past AI chat sessions / conversation history | [search_messages](search-messages.md) |
| Browse thoughts by type, topic, person, or date without a semantic query | [list_thoughts](list-thoughts.md) |
| Browse wiki pages by type or tag without a semantic query | [list_wiki_pages](list-wiki-pages.md) |

**When to prefer `search_all` over targeted tools:** Use `search_all` when you are unsure whether the relevant information was captured as a thought or written into a wiki page, or when you want to surface related content from both stores in a single ranked list. Note that `search_all` uses a lower default similarity threshold (0.45 vs 0.5) and higher default result count (15 vs 10), trading precision for recall.

**When to prefer targeted search:** Use `search_thoughts` or `search_wiki` when you know which store contains the answer, or when you want finer threshold/limit control without noise from the other store.

---

## Read-Before-Write Protocol

**Always follow this sequence before writing or updating a wiki page.** Skipping step 1 risks clobbering existing content.

1. Call `read_wiki_page` with the target title (e.g. `"Alice Smith"`) or known relative path (e.g. `"wiki/people/Alice-Smith.md"`).
2. Inspect the response — confirm whether the page exists and review its current body and frontmatter in full.
3. If the page exists, merge your new information into the existing body, preserving all content that is still accurate. Do not silently drop existing sections.
4. Call `write_wiki_page` with the complete, updated body (including retained existing content). Pass the same `title` and `type` as the existing page to avoid creating a duplicate.
5. Call `append_wiki_log` immediately after a successful write, recording the relative file path and a concise one-line summary of what changed.

> **Note:** `write_wiki_page` performs a full overwrite — there is no patch or merge operation. The complete final body must be supplied on every call.