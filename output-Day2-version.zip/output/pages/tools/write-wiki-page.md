---
title: "write_wiki_page"
description: "Create or overwrite a WikiVault Markdown page with automatic frontmatter, embedding, and Supabase indexing."
audience: both
topics: [wiki, write, pages, knowledge-base, supabase]
mcp_tools: [write_wiki_page, read_wiki_page, append_wiki_log]
doc_phase: 1
reviewed: pending
generated_at: 2026-05-23T08:03:11+00:00
model: claude-sonnet-4-6
---

# `write_wiki_page`

Creates or fully overwrites a WikiVault Markdown page. Frontmatter is built automatically — supply only the body. After writing, the content is embedded and indexed in Supabase.

> **⚠ Read before you write.** If the page may already exist, call [`read_wiki_page`](read-wiki-page.md) first. This tool performs a full overwrite — any content not included in `body` will be lost.

## Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `title` | string | ✅ Yes | — | Human-readable page title, e.g. `"Alice Smith"`. Used to derive the filename and frontmatter. |
| `type` | string (enum) | ✅ Yes | — | Page type — determines the destination subfolder. See [Page types](#page-types) below. |
| `body` | string | ✅ Yes | — | Full Markdown body. Do **not** include frontmatter — it is built automatically. |
| `tags` | array of strings | No | `[]` | Topic tags in `lowercase-kebab` format, e.g. `["machine-learning", "research"]`. |
| `page_sources` | array of strings | No | `[]` | Source URLs, `raw/` file paths, or entry UUIDs that this page is derived from. |
| `cortex_ids` | array of strings | No | `[]` | Supabase `entries` table UUIDs that this page synthesises. Links wiki content back to raw captured thoughts. |
| `status` | string (enum) | No | `"active"` | Page lifecycle status: `active`, `archived`, or `stub`. |

### Page types

| Value | Destination subfolder | Use for |
|-------|-----------------------|---------|
| `wiki_person` | `wiki/people/` | Individual people |
| `wiki_project` | `wiki/projects/` | Projects and initiatives |
| `wiki_concept` | `wiki/concepts/` | Ideas, frameworks, terms |
| `wiki_area` | `wiki/areas/` | Ongoing areas of responsibility |
| `wiki_topic` | `wiki/topics/` | Subject-matter topic hubs |
| `raw_article` | `raw/articles/` | Imported articles |
| `raw_book` | `raw/books/` | Book notes |
| `raw_daily` | `raw/daily/` | Daily notes |
| `raw_attachment` | `raw/attachments/` | Supporting files |

## Returns

A confirmation object containing:

- **`file_path`** — relative path of the written file within WikiVault (e.g. `wiki/projects/Project-Alpha.md`)
- **`supabase_id`** — the Supabase record ID for the indexed page

## Read-before-write protocol

Always follow this sequence when a page may already exist:

1. Call `read_wiki_page` with the page title or file path.
2. If the page exists, merge the existing content with any new information.
3. Call `write_wiki_page` with the merged `body`.
4. Call `append_wiki_log` to record what was done.

Skipping step 1 risks silently deleting content that was previously written.

## Usage examples

### Create a new project page

```json
{
  "title": "Project Alpha",
  "type": "wiki_project",
  "body": "## Overview\n\nProject Alpha is an internal initiative to redesign the onboarding flow.\n\n## Goals\n\n- Reduce time-to-first-value from 14 days to 3 days\n- Improve activation rate by 20%\n\n## Key People\n\n- [[Alice Smith]] — Lead\n- [[Bob Jones]] — Engineering",
  "tags": ["onboarding", "product", "q3-2026"],
  "status": "active"
}
```

### Update an existing person page (safe pattern)

```python
# Step 1 — read
existing = read_wiki_page(identifier="Alice Smith")

# Step 2 — merge new information into existing body
merged_body = existing["body"] + "\n\n## Recent Notes\n\nDiscussed roadmap priorities on 2026-05-20."

# Step 3 — write merged content
result = write_wiki_page(
    title="Alice Smith",
    type="wiki_person",
    body=merged_body,
    tags=["engineering", "leadership"],
    cortex_ids=["d3f1a2b4-...", "89ab12cd-..."],
    status="active"
)

# Step 4 — log the action
append_wiki_log(
    file_path=result["file_path"],
    summary="Updated Alice Smith with roadmap discussion notes from 2026-05-20"
)
```

### Create a stub for later expansion

```json
{
  "title": "Event Sourcing",
  "type": "wiki_concept",
  "body": "## Event Sourcing\n\n_Stub — to be expanded._\n\nA pattern where state changes are stored as a sequence of events rather than current state.",
  "tags": ["architecture", "patterns"],
  "status": "stub"
}
```

### Import with source attribution

```json
{
  "title": "Thinking Fast and Slow — Notes",
  "type": "raw_book",
  "body": "## Key Takeaways\n\n- System 1 vs System 2 thinking\n- Cognitive biases catalogue",
  "tags": ["psychology", "decision-making"],
  "page_sources": ["https://example.com/thinking-fast-slow", "raw/books/original-import.md"],
  "status": "active"
}
```

## Notes

- The `body` parameter must be pure Markdown. Do not include a YAML frontmatter block — the server builds frontmatter from `title`, `type`, `tags`, `status`, `page_sources`, and `cortex_ids`.
- `cortex_ids` creates a traceable link between synthesised wiki knowledge and the raw captured thoughts it was derived from. Populate this when the page content is built from specific `capture_thought` entries.
- This tool performs a **full overwrite**, not a patch. There is no partial-update operation — always read first, merge in memory, then write the complete body.
- After every `write_wiki_page` call, call [`append_wiki_log`](append-wiki-log.md) to maintain an audit trail.