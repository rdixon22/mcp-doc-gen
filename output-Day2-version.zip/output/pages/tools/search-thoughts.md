---
title: "search_thoughts"
description: "Search captured thoughts by semantic similarity — scoped to thoughts only, not WikiVault pages."
audience: both
topics: [search, semantic-search, thoughts, notes]
mcp_tools: [search_thoughts, search_all]
doc_phase: 1
reviewed: pending
generated_at: 2026-05-23T08:01:17+00:00
model: claude-sonnet-4-6
---

# search_thoughts

Search your captured notes by meaning. `search_thoughts` finds notes that are semantically relevant to your query — matching by concept and intent, not just keywords.

**Scope:** this tool searches captured thoughts only. It does not search WikiVault pages. Use [`search_all`](search-all.md) to query both sources in a single call.

## Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `query` | string | Yes | — | What to search for |
| `limit` | number | No | `10` | Maximum number of results to return |
| `threshold` | number | No | `0.5` | Minimum similarity score, between 0 and 1 (inclusive). Lower values return more results; higher values return only close matches. |

### Threshold guidance

| Threshold | Effect |
|-----------|--------|
| `0.3–0.4` | Wide net — returns loosely related results; useful when recall matters more than precision |
| `0.5` | Default balance between relevance and coverage |
| `0.7+` | High precision — only returns strongly relevant results; may miss useful context |

## Returns

A ranked list of matching thoughts. Each result includes the thought's content and associated metadata as stored at capture time. Results are ordered by descending similarity score.

> **Note:** The exact response schema is determined by the server runtime. Field names and structure should be treated as implementation details until confirmed against a live response.

## Usage examples

### Basic search

```json
{
  "name": "search_thoughts",
  "arguments": {
    "query": "decisions about the product roadmap"
  }
}
```

Returns up to 10 thoughts with similarity ≥ 0.5 related to product roadmap decisions.

### Wide search with more results

```json
{
  "name": "search_thoughts",
  "arguments": {
    "query": "decisions about the product roadmap",
    "limit": 25,
    "threshold": 0.3
  }
}
```

Casts a wider net — useful when you suspect relevant notes may be phrased differently or only tangentially related to the query.

### High-precision search

```json
{
  "name": "search_thoughts",
  "arguments": {
    "query": "Alice's feedback on the onboarding flow",
    "limit": 5,
    "threshold": 0.7
  }
}
```

Returns only highly relevant results — appropriate when you want to surface a specific note you know exists.

## Scope limitation

`search_thoughts` does not search WikiVault pages (people, projects, concepts, areas, topics, or raw content). If you need results from both sources:

- Use [`search_all`](search-all.md) for a combined query across thoughts and wiki pages. Results from `search_all` are tagged by source (`[thought]` or `[wiki]`).
- Use [`search_wiki`](search-wiki.md) to search wiki pages only.

## Related tools

- [`capture_thought`](capture-thought.md) — save a new thought
- [`list_thoughts`](list-thoughts.md) — browse thoughts chronologically with filters (type, topic, person, date range)
- [`thought_stats`](thought-stats.md) — get a count and breakdown of all captured thoughts
- [`search_all`](search-all.md) — semantic search across thoughts and wiki pages together
- [`search_messages`](search-messages.md) — search past AI chat conversation history