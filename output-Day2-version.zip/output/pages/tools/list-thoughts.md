---
title: "list_thoughts"
description: "Browse recently captured thoughts in chronological order with optional filters for type, topic, person, and recency."
audience: both
topics: [thoughts, browse, filter, chronological, list]
mcp_tools: [list_thoughts]
doc_phase: 1
reviewed: pending
generated_at: 2026-05-23T08:01:36+00:00
model: claude-sonnet-4-6
---

# list_thoughts

Browse recently captured thoughts in reverse-chronological order. Use this tool when the user wants to **review recent activity** or **enumerate thoughts by category** — not when they're querying by meaning. For semantic search, use [`search_thoughts`](search-thoughts.md) instead.

All parameters are optional and combinable. Omitting all parameters returns the 10 most recently captured thoughts.

## Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `limit` | number | No | `10` | Maximum number of results to return. |
| `type` | string | No | — | Filter to a single thought type. Must be one of: `observation`, `task`, `idea`, `reference`, `person_note`. |
| `topic` | string | No | — | Filter by topic tag (exact match against auto-extracted topics). |
| `person` | string | No | — | Filter by person mentioned in the thought. |
| `days` | number | No | — | Restrict results to thoughts captured within the last N days. |

### `type` values

| Value | When to use |
|-------|-------------|
| `observation` | Factual notes, things noticed |
| `task` | Action items, to-dos |
| `idea` | Speculative or creative thoughts |
| `reference` | Links, citations, source material |
| `person_note` | Notes about a specific person |

## Returns

An ordered list of thought entries matching the applied filters. Each entry includes:

- **content** — the captured text
- **type** — auto-classified thought type
- **topics** — extracted topic tags
- **people** — people mentioned
- **action_items** — any action items extracted
- **captured_at** — ISO 8601 timestamp

Results are sorted newest-first.

## Usage Examples

### Recent thoughts (no filters)

```json
{
  "name": "list_thoughts",
  "arguments": {}
}
```

Returns the 10 most recently captured thoughts.

---

### Tasks from the last 7 days

```json
{
  "name": "list_thoughts",
  "arguments": {
    "type": "task",
    "days": 7
  }
}
```

Returns up to 10 tasks captured in the past week.

---

### All person_notes mentioning a specific colleague

```json
{
  "name": "list_thoughts",
  "arguments": {
    "type": "person_note",
    "person": "Alice Smith",
    "limit": 25
  }
}
```

Returns up to 25 notes that mention Alice Smith, newest first.

---

### Ideas tagged with a given topic

```json
{
  "name": "list_thoughts",
  "arguments": {
    "type": "idea",
    "topic": "product-strategy"
  }
}
```

Returns ideas tagged `product-strategy`.

---

### Recent activity across all types

```json
{
  "name": "list_thoughts",
  "arguments": {
    "days": 3,
    "limit": 20
  }
}
```

Returns up to 20 thoughts captured in the last 3 days, regardless of type.

## When to use `list_thoughts` vs `search_thoughts`

| Situation | Tool |
|-----------|------|
| "Show me what I captured recently" | `list_thoughts` |
| "What tasks do I have from this week?" | `list_thoughts` with `type=task`, `days=7` |
| "Show all notes about Alice" | `list_thoughts` with `person=Alice` |
| "What have I captured about machine learning?" | [`search_thoughts`](search-thoughts.md) |
| "Find thoughts related to the Q3 planning discussion" | [`search_thoughts`](search-thoughts.md) |
| "Search across thoughts and wiki pages together" | [`search_all`](search-all.md) |