---
title: "search_wiki"
description: "Search WikiVault pages by semantic similarity to find the most relevant wiki entries when you do not know the exact page title."
audience: both
topics: [search, wiki, semantic-search, wikivault]
mcp_tools: [search_wiki]
doc_phase: 1
reviewed: pending
generated_at: 2026-05-23T08:04:32+00:00
model: claude-sonnet-4-6
---

# search_wiki

Search WikiVault pages by semantic similarity. Returns wiki entries ranked by relevance score. Use this tool when you have a concept, name, or topic in mind but do not know the exact page title. For browsing all pages of a given type without a search term, use [list_wiki_pages](list-wiki-pages.md) instead. To include captured thoughts in the same query, use [search_all](search-all.md).

## Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `query` | string | ✅ Yes | — | What to search for |
| `limit` | number | No | `10` | Maximum number of results to return |
| `threshold` | number | No | `0.5` | Minimum similarity score (0–1); results below this value are excluded |
| `type` | string (enum) | No | — | Restrict results to one page type (see valid values below) |

### `type` enum values

| Value | Description |
|-------|-------------|
| `wiki_person` | People pages |
| `wiki_project` | Project pages |
| `wiki_concept` | Concept pages |
| `wiki_area` | Area pages |
| `wiki_topic` | Topic pages |
| `raw_article` | Imported articles |
| `raw_book` | Book notes |
| `raw_daily` | Daily notes |
| `raw_attachment` | Attachment files |

### Threshold guidance

| Threshold | Effect |
|-----------|--------|
| `0.3–0.4` | Broad — returns loosely related pages; useful for exploration |
| `0.5` | Default — balanced precision and recall |
| `0.7+` | Strict — only highly similar pages; use when confident in query phrasing |

## Returns

A ranked list of matching WikiVault pages. Each result includes:

- **title** — the page title
- **type** — page type (one of the enum values above)
- **tags** — array of topic tags
- **file_path** — relative path to the page file (e.g. `wiki/concepts/Machine-Learning-Infrastructure.md`)
- **similarity** — similarity score between 0 and 1
- **excerpt** — a short snippet of the page content

Results are ordered by descending similarity score.

## Scope

`search_wiki` searches **WikiVault pages only**. It does not search captured thoughts from the MCP, web, or Discord sources. Use:

- [search_thoughts](search-thoughts.md) — to search only captured thoughts
- [search_all](search-all.md) — to search both thoughts and wiki pages together
- [list_wiki_pages](list-wiki-pages.md) — to enumerate pages by type with no query term

## Usage examples

### Find a concept page before creating or updating

Check whether a concept page already exists before writing a new one:

```json
{
  "name": "search_wiki",
  "arguments": {
    "query": "machine learning infrastructure",
    "type": "wiki_concept",
    "limit": 5
  }
}
```

If the top result has a similarity score above `0.75` and a matching title, read that page with [read_wiki_page](read-wiki-page.md) before deciding whether to update it or create a new one.

### Find a person page by role or association

```json
{
  "name": "search_wiki",
  "arguments": {
    "query": "backend engineer data pipeline team",
    "type": "wiki_person",
    "threshold": 0.4
  }
}
```

### Broad search across all wiki content

```json
{
  "name": "search_wiki",
  "arguments": {
    "query": "vector database embedding strategy",
    "limit": 15,
    "threshold": 0.35
  }
}
```

## Recommended workflow: find-then-write

When an agent needs to create or update a wiki page, always run `search_wiki` first:

1. Call `search_wiki` with the intended topic and relevant `type`.
2. If a result has similarity ≥ 0.7, call [read_wiki_page](read-wiki-page.md) on that result's `file_path`.
3. Decide whether to update the existing page or create a new one.
4. Call [write_wiki_page](write-wiki-page.md) with the full merged content.
5. Call [append_wiki_log](append-wiki-log.md) to record the action.

Skipping step 1–3 risks silently overwriting existing structured knowledge.