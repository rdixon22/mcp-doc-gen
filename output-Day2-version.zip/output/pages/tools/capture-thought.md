---
title: "capture_thought"
description: "Save a new atomic note or thought to Cortex with automatic embedding and metadata extraction."
audience: both
topics: [capture, notes, thoughts, metadata, embedding]
mcp_tools: [capture_thought]
doc_phase: 1
reviewed: pending
generated_at: 2026-05-23T08:00:32+00:00
model: claude-sonnet-4-6
---

# capture_thought

Save a new note or thought to the Cortex Thoughts store. The server automatically generates a vector embedding and extracts metadata — including a type classification, topics, people mentioned, and any action items — from the content you provide.

Use this tool whenever the user wants to preserve a discrete piece of information: an insight from reading, a decision made in a meeting, an observation, or a task to follow up on.

## Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `content` | string | ✅ Yes | — | The thought to capture — a clear, self-contained statement |

### Parameter notes

**`content`** — Write this as a standalone statement that will be meaningful without additional context. Include who was involved, what was decided, and why if relevant. A thought that reads as complete in isolation will surface more usefully in future searches.

> ✅ Good: `"Decided to defer the API redesign until Q3 because the mobile team needs the existing endpoints stable through the launch."`
>
> ⚠️ Weak: `"API redesign deferred"` — lacks context that may not be recoverable later.

## Returns

A confirmation that the entry was saved, including the assigned UUID and the metadata extracted from the content. The exact fields returned depend on the server implementation; treat returned metadata (type classification, topics, people) as illustrative of what the server may extract, not as a guaranteed schema.

## Usage examples

### Capture a decision

```json
{
  "tool": "capture_thought",
  "arguments": {
    "content": "Decided to use Supabase pgvector for semantic search instead of a dedicated vector DB — simpler infrastructure, good enough performance for our scale, and we already have Supabase in the stack."
  }
}
```

### Capture a task

```json
{
  "tool": "capture_thought",
  "arguments": {
    "content": "Follow up with Sarah by end of week about the budget approval for the new hire — she mentioned needing the headcount justification document."
  }
}
```

### Capture an insight from reading

```json
{
  "tool": "capture_thought",
  "arguments": {
    "content": "From Thinking Fast and Slow: System 1 thinking explains why people anchor on the first number they hear in negotiations — important to set the anchor deliberately."
  }
}
```

## Best practices

**Write self-contained statements.** Each thought is stored as an atomic unit. Future retrieval depends on the content alone — there is no surrounding conversation to provide context. Include names, dates, and rationale when they matter.

**One idea per capture.** If a meeting produced three distinct decisions, call `capture_thought` three times. Granular entries are easier to find and link to wiki pages later.

**Consider downstream wiki updates.** After capturing a thought about a person, project, or concept that already has a wiki page, check whether the wiki page should be updated to reflect the new information. Use [`read_wiki_page`](read-wiki-page.md) to retrieve the existing page and [`write_wiki_page`](write-wiki-page.md) to update it — always read before writing.

**Use search to avoid duplication.** Before capturing a thought you may have already saved, run [`search_thoughts`](search-thoughts.md) to check for near-duplicates.