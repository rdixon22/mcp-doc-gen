---
title: "thought_stats"
description: "Returns a high-level statistical summary of all captured thoughts: total count, type breakdown, top topics, and most-mentioned people."
audience: both
topics: [thoughts, statistics, summary, overview]
mcp_tools: [thought_stats]
doc_phase: 1
reviewed: pending
generated_at: 2026-05-23T08:02:43+00:00
model: claude-sonnet-4-6
---

# thought_stats

Returns a high-level statistical summary of all captured thoughts. Use this to understand the breadth and composition of your captured knowledge at a glance — without needing to retrieve individual entries.

## Parameters

This tool takes no parameters.

## Returns

A structured summary containing:

- **Total count** — the number of captured thoughts
- **Type breakdown** — count of thoughts per type (e.g. how many are tasks, ideas, observations, etc.)
- **Top topics** — the most frequently tagged topics across all thoughts
- **Top people** — the most frequently mentioned people across all thoughts

The exact field names and structure depend on the server's response format.

## Usage

```json
{
  "tool": "thought_stats",
  "arguments": {}
}
```

### Example: Weekly review orientation

Before a weekly review, call `thought_stats` to see how many entries were logged, which types dominate (e.g. tasks vs. ideas), and which topics appeared most this period.

```json
{
  "tool": "thought_stats",
  "arguments": {}
}
```

**Example response (illustrative):**

```json
{
  "total": 47,
  "by_type": {
    "task": 12,
    "idea": 18,
    "observation": 9,
    "reference": 5,
    "person_note": 3
  },
  "top_topics": ["product-strategy", "engineering", "hiring"],
  "top_people": ["Alice Smith", "Bob Chen"]
}
```

> **Note:** The response shape above is illustrative. The actual fields returned depend on the server implementation.

## When to use

- **Session start** — run once to orient yourself before querying or writing new entries.
- **After bulk capture** — confirm that a batch of thoughts was stored and categorised as expected.
- **Weekly or periodic review** — identify which topics and people dominated a given period before drilling into specifics.

`thought_stats` gives an aggregate view. To retrieve individual entries, use the thought browsing and search tools available in this server.