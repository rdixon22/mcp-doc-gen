---
title: "append_wiki_log"
description: "Appends a timestamped one-line audit entry to log.md in WikiVault, documenting an action taken on a specific wiki page."
audience: both
topics: [wiki, audit-trail, logging, write-operations]
mcp_tools: [append_wiki_log]
doc_phase: 1
reviewed: pending
generated_at: 2026-05-23T08:05:18+00:00
model: claude-sonnet-4-6
---

# append_wiki_log

Writes a timestamped one-line entry to `log.md` in WikiVault, recording which page was acted on and what was done. Call this after every [`write_wiki_page`](write-wiki-page.md) invocation and after any other significant decision — including choosing *not* to create or update a page. This log is the persistent audit trail of all LLM-driven wiki changes.

## Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `file_path` | string | ✅ yes | — | Relative path of the WikiVault page that was acted on (e.g. `wiki/projects/Atlas.md`) |
| `summary` | string | ✅ yes | — | One-line human-readable description of what was done. Maximum 200 characters. |

### Parameter notes

- **`file_path`** should be the relative path as returned by [`write_wiki_page`](write-wiki-page.md) or [`list_wiki_pages`](list-wiki-pages.md). Use the same path you passed to the write operation for consistency.
- **`summary`** should be specific enough to be meaningful when reviewed later. Include *what* changed and *why* if possible — e.g. `"Updated goals and status section with Q3 decisions from captured thoughts"` rather than `"Updated page"`.

## Returns

Confirmation that the log entry was appended, including the timestamp that was recorded in `log.md`.

```
Appended log entry at 2026-05-23T08:05:18Z → wiki/projects/Atlas.md: "Updated goals and status section with Q3 decisions from captured thoughts"
```

## When to call this tool

Call `append_wiki_log` after:

1. Every successful `write_wiki_page` — pass the same `file_path` that was written.
2. Any significant decision, such as deciding *not* to create a page and why.
3. A `migrate_vault_file` import that you want to record explicitly.

Do not skip this call after writes. The `log.md` file is the canonical history of LLM-driven changes to WikiVault and is relied on for auditing and debugging.

## Usage examples

### After updating an existing project page

```json
{
  "file_path": "wiki/projects/Atlas.md",
  "summary": "Updated goals and status section with Q3 decisions from captured thoughts"
}
```

### After creating a new person page

```json
{
  "file_path": "wiki/people/Alice-Smith.md",
  "summary": "Created new person page for Alice Smith based on three captured thoughts"
}
```

### After deciding not to create a page

```json
{
  "file_path": "wiki/concepts/machine-learning.md",
  "summary": "Skipped creation — existing page already covers this topic; no update needed"
}
```

### Typical write + log sequence

```json
// Step 1 — read first (if the page may exist)
{ "tool": "read_wiki_page", "identifier": "wiki/projects/Atlas.md" }

// Step 2 — write the updated content
{
  "tool": "write_wiki_page",
  "title": "Atlas",
  "type": "wiki_project",
  "body": "## Goals\n\n...",
  "tags": ["q3", "infrastructure"]
}

// Step 3 — log the action immediately after
{
  "tool": "append_wiki_log",
  "file_path": "wiki/projects/Atlas.md",
  "summary": "Updated goals and status section with Q3 decisions from captured thoughts"
}
```

## Related tools

| Tool | Relationship |
|------|-------------|
| [`write_wiki_page`](write-wiki-page.md) | Primary trigger — always follow a write with `append_wiki_log` |
| [`read_wiki_page`](read-wiki-page.md) | Call before writing; the log records what the subsequent write changed |
| [`migrate_vault_file`](migrate-vault-file.md) | May also warrant a log entry after import |