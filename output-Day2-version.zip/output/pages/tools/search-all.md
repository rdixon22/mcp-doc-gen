---
title: "search_all"
description: "Semantic search across all Cortex content — captured thoughts and WikiVault pages — in a single unified query."
audience: both
topics: [search, semantic-search, thoughts, wiki, unified-search]
mcp_tools: [search_all]
doc_phase: 1
reviewed: pending
generated_at: 2026-05-23T08:05:38+00:00
model: claude-sonnet-4-6
---

# search_all

Performs a semantic similarity search across **all content in Cortex simultaneously**: captured thoughts (sourced from web, Discord, and MCP) and WikiVault pages. Results from both stores are merged into a single ranked list, with each item tagged `[thought]` or `[wiki]` to indicate its origin.

Use `search_all` when you need the broadest possible context — for example, before drafting a wiki page, synthesising a topic summary, or answering an open-ended "what do I know about X?" question.

## Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `query` | string | **Yes** | — | The search query. Natural-language phrases work well; the search uses semantic (embedding) similarity, not keyword matching. |
| `limit` | number | No | `15` | Maximum number of results to return across both stores combined. |
| `threshold` | number | No | `0.45` | Minimum similarity score (0–1) a result must meet to be included. Lower than the default for single-store tools (0.5) to surface cross-store matches that might score slightly lower but are still relevant. |

## Returns

A unified, relevance-ranked list of results. Each result includes:

- **Source tag** — `[thought]` or `[wiki]`, indicating which store the result came from.
- **Content / excerpt** — the thought text or a wiki page excerpt.
- **Similarity score** — a float between 0 and 1 indicating semantic closeness to the query.
- **Metadata** — for thoughts: type, topics, people, timestamp; for wiki pages: page type, tags, file path.

## Choosing the right search tool

| Goal | Recommended tool |
|------|-----------------|
| Broadest context — thoughts **and** wiki together | **`search_all`** |
| Only captured thoughts (notes, tasks, observations) | [`search_thoughts`](search-thoughts.md) |
| Only WikiVault pages | [`search_wiki`](search-wiki.md) |
| Previous AI chat conversation history | [`search_messages`](search-messages.md) |
| Browse by recency or filter by type/person | [`list_thoughts`](list-thoughts.md) |
| Browse wiki by page type or tag | [`list_wiki_pages`](list-wiki-pages.md) |

The `threshold` default of `0.45` (vs. `0.5` for scoped tools) is intentional: cross-store queries benefit from a slightly looser threshold so that relevant content from the less-dominant store is not silently excluded.

## Usage examples

### Open-ended topic research before writing a wiki page

```json
{
  "name": "search_all",
  "arguments": {
    "query": "observability monitoring distributed systems",
    "limit": 20
  }
}
```

Gather everything Cortex knows about observability — both raw thoughts captured over time and any existing wiki concepts — in a single pass before drafting or updating a wiki concept page.

### Tighter relevance filter for a focused question

```json
{
  "name": "search_all",
  "arguments": {
    "query": "Alice Smith product roadmap decisions",
    "limit": 10,
    "threshold": 0.6
  }
}
```

Raise `threshold` to `0.6` when you want only high-confidence matches and are willing to miss borderline results.

### Minimal call — defaults only

```json
{
  "name": "search_all",
  "arguments": {
    "query": "machine learning experiment results"
  }
}
```

Returns up to 15 results with a similarity threshold of 0.45 across all content stores.

## Notes

- Results are ranked by similarity score descending; the merged list is not split by source — a wiki page and a thought can appear interleaved based on relevance.
- `search_all` does **not** search chat message history. Use [`search_messages`](search-messages.md) for that.
- When writing or updating a wiki page, the recommended workflow is: call `search_all` first to collect context, then call [`read_wiki_page`](read-wiki-page.md) if the page may already exist, then call [`write_wiki_page`](write-wiki-page.md).