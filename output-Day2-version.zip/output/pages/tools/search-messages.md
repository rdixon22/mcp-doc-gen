---
title: "search_messages"
description: "Search past AI chat conversation messages by semantic similarity to retrieve context from previous sessions."
audience: both
topics: [search, chat-history, semantic-search, conversation-memory]
mcp_tools: [search_messages]
doc_phase: 1
reviewed: pending
generated_at: 2026-05-23T08:02:54+00:00
model: claude-sonnet-4-6
---

# `search_messages`

Search across all past AI chat conversation messages by semantic similarity. Use this tool when you need to find something discussed in a previous chat session — a decision, a design choice, a fact mentioned in passing — and the user does not know exactly when or in which session it came up.

**Scope:** `search_messages` covers only the conversation message history store. It does not search captured thoughts or WikiVault pages. Use [`search_all`](search-all.md) to query all stores simultaneously.

## Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `query` | string | Yes | — | What to search for in chat history |
| `limit` | number | No | `10` | Maximum number of message results to return |

### Parameter notes

- **`query`** — A natural-language phrase or question describing what you are looking for. Matching is by semantic similarity, not keyword — phrasing does not need to be exact.
- **`limit`** — Controls how many messages are returned. Increase if you expect the topic to span many turns or sessions. There is no built-in similarity threshold parameter for this tool; results are ranked by score and truncated at `limit`.

## Returns

A ranked list of matching chat messages. Each result includes:

- **Message content** — the text of the matching message
- **Session context** — information identifying which conversation session the message belongs to
- **Similarity score** — relevance score indicating how closely the message matches the query

Results are ordered from most to least similar.

## Usage examples

### Find a past decision

```json
{
  "name": "search_messages",
  "arguments": {
    "query": "what did we decide about the API design?"
  }
}
```

Use this when the user asks "didn't we talk about this before?" and you need to surface the relevant portion of a prior session.

### Retrieve more results for a broad topic

```json
{
  "name": "search_messages",
  "arguments": {
    "query": "authentication strategy OAuth JWT",
    "limit": 25
  }
}
```

Increasing `limit` is useful when a topic was discussed across multiple sessions or messages.

### Locate a specific fact mentioned in passing

```json
{
  "name": "search_messages",
  "arguments": {
    "query": "the deadline for the launch was moved to Q3"
  }
}
```

## Choosing the right search tool

| You want to search… | Use |
|---------------------|-----|
| Past chat conversations | `search_messages` |
| Captured thoughts and notes | [`search_thoughts`](search-thoughts.md) |
| WikiVault pages | [`search_wiki`](search-wiki.md) |
| Everything at once | [`search_all`](search-all.md) |

`search_messages` is the only tool that reaches into conversation history. If a user references something "we talked about" in a previous session, start here before falling back to `search_all`.