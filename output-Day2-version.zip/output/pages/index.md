---
title: "Cortex MCP Server — Overview"
description: "A personal knowledge-management MCP server maintaining two distinct stores: atomic Thoughts and long-form WikiVault pages, both semantically searchable."
audience: both
topics: [knowledge-management, semantic-search, wiki, notes, personal-knowledge-base]
mcp_tools: [capture_thought, search_thoughts, list_thoughts, thought_stats, search_messages, write_wiki_page, read_wiki_page, search_wiki, list_wiki_pages, append_wiki_log, search_all, migrate_vault_file]
doc_phase: 1
reviewed: pending
generated_at: 2026-05-23T07:59:04+00:00
model: claude-sonnet-4-6
---

# Cortex MCP Server — Overview

Cortex is a personal knowledge-management MCP server (v2.0.0) that gives AI agents and human developers a unified interface for capturing, retrieving, and synthesising personal knowledge. It maintains two complementary stores — **Thoughts** and **WikiVault** — each with its own data model and access patterns, plus cross-store search that spans both simultaneously.

## Two Stores, One System

### Thoughts Store

Thoughts are atomic, self-contained notes captured from any source — the web, Discord, direct MCP calls, or conversation. When a thought is saved, Cortex automatically:

- Embeds the content as a vector for semantic search
- Extracts structured metadata: **type** (`observation`, `task`, `idea`, `reference`, `person_note`), **topics**, **people mentioned**, and **action items**

Thoughts are persisted as rows in **Supabase**, queryable by meaning, by metadata filter, or chronologically. They are the raw material of your knowledge base — quick, unedited, and accumulating over time.

### WikiVault Store

WikiVault contains long-form, LLM-maintained **Markdown pages** organised into typed subfolders:

| Type | Subfolder purpose |
|---|---|
| `wiki_person` | People profiles |
| `wiki_project` | Project pages |
| `wiki_concept` | Concepts and ideas |
| `wiki_area` | Life/work areas |
| `wiki_topic` | Topic overviews |
| `raw_article` | Imported articles |
| `raw_book` | Imported book notes |
| `raw_daily` | Daily notes |
| `raw_attachment` | Other imported files |

Each page is a **Markdown file on the filesystem** with auto-generated YAML frontmatter (you supply only the body). Pages are also indexed in Supabase alongside their vector embeddings, making them semantically searchable. WikiVault pages are the synthesised, curated layer — built from raw thoughts, imported content, and deliberate authoring.

## Functional Areas

### 1. Thought Capture & Retrieval

Save new insights, decisions, tasks, or observations with [capture_thought](tools/capture-thought.md). Retrieve them semantically with [search_thoughts](tools/search-thoughts.md), browse them chronologically with [list_thoughts](tools/list-thoughts.md), or get an aggregate summary with [thought_stats](tools/thought-stats.md).

### 2. Wiki Authoring

Create and maintain WikiVault pages with [write_wiki_page](tools/write-wiki-page.md) and [read_wiki_page](tools/read-wiki-page.md). Browse pages by type or tag with [list_wiki_pages](tools/list-wiki-pages.md). Every write should be preceded by a read (to avoid clobbering existing content) and followed by an [append_wiki_log](tools/append-wiki-log.md) call to maintain an audit trail.

### 3. Cross-Store Search

[search_all](tools/search-all.md) performs a single semantic query across both Thoughts and WikiVault simultaneously, returning results tagged `[thought]` or `[wiki]` by source. Use this when you need the broadest context before answering a question or starting a new wiki entry.

### 4. Conversation Memory

[search_messages](tools/search-messages.md) searches across all past AI chat session messages by semantic similarity — useful for recovering context from earlier conversations that wasn't formally captured as a thought.

### 5. Vault Migration

[migrate_vault_file](tools/migrate-vault-file.md) is a one-time import tool that copies a file from an external MainVault into WikiVault's `raw/` subfolder, adding standardised frontmatter, stripping Dataview blocks, and indexing it in Supabase. The original source file is never modified.

## Typical Workflows

### Capture → Synthesise

1. User shares an insight; call `capture_thought` to save it with automatic metadata extraction.
2. Later, call `search_thoughts` or `list_thoughts` to gather related thoughts on the same topic.
3. Call `read_wiki_page` to check whether a relevant wiki page already exists.
4. Call `write_wiki_page` to create or update a concept/person/project page that synthesises the captured thoughts, passing their UUIDs in `cortex_ids`.
5. Call `append_wiki_log` to record what was written and why.

### Research → Write

1. Call `search_all` with a broad query to surface everything Cortex knows on a topic across both stores.
2. Review `[thought]` and `[wiki]` results to understand the current state of knowledge.
3. Call `read_wiki_page` on the most relevant existing page.
4. Call `write_wiki_page` with an updated or new page body.
5. Call `append_wiki_log`.

### Browse → Promote

1. Call `list_thoughts` filtered by `type: "idea"` and a recent `days` window to find ideas worth developing.
2. For each promising idea, call `search_wiki` to see if a wiki concept page already exists.
3. Call `write_wiki_page` with type `wiki_concept` to promote the idea into a permanent entry.
4. Call `append_wiki_log`.

### Import → Link

1. Call `migrate_vault_file` to import a Markdown article from MainVault into WikiVault as `raw_article`.
2. Call `search_wiki` to find existing wiki pages related to the article's content.
3. Call `read_wiki_page` on the most relevant page, then `write_wiki_page` to add a reference to the imported article via `page_sources`.
4. Call `append_wiki_log`.

## Architecture Notes

- **Transport**: stdio — Cortex runs as a local process; all MCP communication is over standard input/output.
- **Semantic search**: vector embeddings are stored and queried in Supabase using pgvector. Both thoughts and wiki pages are embedded on write.
- **Filesystem layout**: WikiVault pages live in typed subfolders on disk. The `type` parameter of `write_wiki_page` and `migrate_vault_file` determines the destination subfolder automatically.
- **Frontmatter**: never include frontmatter in the `body` parameter of `write_wiki_page` — the server builds it from the structured parameters (`title`, `type`, `tags`, `status`, etc.).
- **Audit trail**: `append_wiki_log` writes a timestamped one-line entry to `log.md` after every wiki write. Treat this as mandatory protocol, not optional.
- **Read-before-write**: always call `read_wiki_page` before `write_wiki_page` when a page might already exist. Passing `write_wiki_page` without reading first risks silently overwriting curated content.

## Reference

See the [Tools Reference](tools/index.md) for a complete listing of all tools, parameter tables, and decision guidance for choosing between overlapping search and write tools.